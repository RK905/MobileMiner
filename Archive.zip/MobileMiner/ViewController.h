//
//  ViewController.h
//  MobileMiner
//
//  Created by Elias Limneos on 11/12/2017.
//  Copyright © 2017 Elias Limneos. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "objc/runtime.h"
@interface ViewController : UINavigationController
@end

