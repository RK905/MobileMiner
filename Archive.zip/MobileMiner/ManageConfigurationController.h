//
//  SelectConfigurationController.h
//  MobileMiner
//
//  Created by Elias Limneos on 16/12/2017.
//  Copyright © 2017 Elias Limneos. All rights reserved.
//

#include "GrayTableController.h"
@interface ManageConfigurationController : GrayTableController
-(id)initReadOnly;
@end


