//
//  ViewController.m
//  MobileMiner
//
//  Created by Elias Limneos on 11/12/2017.
//  Copyright © 2017 Elias Limneos. All rights reserved.
//

#include "ViewController.h"
@implementation ViewController 
@end
