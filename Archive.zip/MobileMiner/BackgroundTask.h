//
//  BackgroundTask.h
//  MobileMiner
//
//  Created by Elias Limneos on 14/12/2017.
//  Copyright © 2017 Elias Limneos. All rights reserved.
//
//
//  Credits - Original Source : https://github.com/yarodevuci/backgroundTask
//


#import <UIKit/UIKit.h>
@interface BackgroundTask : NSObject
-(void)startBackgroundTask;
-(void)stopBackgroundTask;
@end

